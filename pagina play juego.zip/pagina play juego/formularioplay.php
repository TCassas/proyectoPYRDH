<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Document</title>
    <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
    <link rel="stylesheet" type="text/css" href="css/estilo1.css">
</head>
<body>
    
        <header>
            <div id="usuario">
            <p>usuario</p>
            <button name="" id=""><ion-icon name="person"></ion-icon></button>
            </div>
           
        </header>
    </div>
    <div id="cajaprincipal">
        

        <div for="" id="">

                <img src="imagenes/images.jpg" alt=""><br>

            <button name="" id="botones"><p id="play">PLAY</p></button>
            <button name="" id="botones"><p>CREATE</p></button>
        
            <div id="botoncitos">
                      <button name="" id="botoneschicos"><ion-icon name="help"></ion-icon></button>
                    <button name="" id="botoneschicos"><ion-icon name="settings"></ion-icon></button>
            </div>
      
        </div>
    </div>
</body>
</html>